import os
import json

def get_env_config():
    env = os.getenv("APP_ENV", "development")
    config_path = f"config/{env}.json"
    with open(config_path) as f:
        return json.load(f)
