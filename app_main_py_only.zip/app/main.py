# app/main.py

import streamlit as st
import os
from core.router import load_routes
from core.auth import authenticate_user
from core.plugins import initialize_plugins
from utils.env import get_env_config

# Load configuration dynamically based on APP_ENV (e.g., production, staging)
config = get_env_config()

# Set basic Streamlit page configuration
st.set_page_config(
    page_title="GBT Editor",
    page_icon="🧠",
    layout="wide",
    initial_sidebar_state="expanded"
)

# Display app title
st.title("GBT Editor")

# Authenticate user
user = authenticate_user(config)

# Proceed if authenticated
if user:
    st.sidebar.success(f"Welcome, {user['username']}")

    # Initialize and isolate plugins based on user's access/roles
    initialize_plugins(user, config)

    # Load plugin-based or custom-defined routes
    load_routes(user, config)

else:
    st.warning("Please log in to access the editor.")
