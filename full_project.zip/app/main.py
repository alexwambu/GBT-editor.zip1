# app/main.py
import streamlit as st
import json
import os
from core.router import load_routes
from core.auth import authenticate_user
from core.plugins import initialize_plugins
from utils.env import get_env_config

# Load configuration based on environment variable
config = get_env_config()

# Set Streamlit page config
st.set_page_config(page_title="GBT Editor", layout="wide")

# Initialize authentication
user = authenticate_user(config)

if user:
    st.sidebar.success(f"Logged in as: {user['username']}")
    
    # Initialize plugin environment and routing
    initialize_plugins(user, config)
    load_routes(user, config)
else:
    st.warning("Please log in to continue.")
