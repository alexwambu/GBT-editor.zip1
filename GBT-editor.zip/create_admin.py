
from app.db import SessionLocal, User
import bcrypt

def create_admin():
    username = input("Admin username: ")
    email = input("Email: ")
    password = input("Password: ")

    hashed = bcrypt.hashpw(password.encode(), bcrypt.gensalt()).decode()

    db = SessionLocal()
    user = User(username=username, email=email, password=hashed, role="admin")
    db.add(user)
    db.commit()
    db.close()

    print("✅ Admin created successfully!")

if __name__ == "__main__":
    create_admin()
