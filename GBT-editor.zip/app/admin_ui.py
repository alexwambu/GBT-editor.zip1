
import streamlit as st
import json

USER_PLUGIN_MAP_PATH = "user_plugins.json"

def load_user_plugin_map():
    try:
        with open(USER_PLUGIN_MAP_PATH, "r") as f:
            return json.load(f)
    except:
        return {}

def save_user_plugin_map(data):
    with open(USER_PLUGIN_MAP_PATH, "w") as f:
        json.dump(data, f, indent=2)

def admin_ui():
    st.subheader("🔧 Admin: Assign Plugins to Users")
    data = load_user_plugin_map()
    users = list(data.keys())
    new_user = st.text_input("➕ Add new user")
    if st.button("Add User") and new_user:
        data[new_user] = []
        save_user_plugin_map(data)

    selected_user = st.selectbox("Select User", users)
    plugins = os.listdir("plugins")
    selected_plugins = st.multiselect("Assign Plugins", plugins, default=data.get(selected_user, []))

    if st.button("Save Assignments"):
        data[selected_user] = selected_plugins
        save_user_plugin_map(data)
        st.success("✅ Plugin access updated!")
