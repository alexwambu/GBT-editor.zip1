
import streamlit as st

def view_logs(log_file="app/app.log"):
    st.subheader("📜 Live Logs")
    if st.button("🔄 Refresh Logs"):
        try:
            with open(log_file, "r") as f:
                logs = f.readlines()[-100:]  # tail last 100 lines
            st.text("".join(logs))
        except FileNotFoundError:
            st.warning("Log file not found.")
