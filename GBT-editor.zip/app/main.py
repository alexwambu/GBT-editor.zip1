...

# Add deployment tab
elif app_mode == "Deploy":
    from app.deploy import deploy_interface
    deploy_interface()


from app.deploy_from_app import deploy_from_app

with st.sidebar:
    if st.button("🚀 Deploy GBT-editor"):
        deploy_from_app()


from app.github_oauth import github_oauth_flow, get_github_token, deploy_status
from app.streamlit_api import configure_secrets

with st.sidebar.expander("🔐 GitHub OAuth & Deploy"):
    github_oauth_flow()
    token = get_github_token()
    if token:
        repo = st.text_input("GitHub Repo (e.g., user/GBT-editor)")
        if st.button("Check Deploy Status"):
            deploy_status(repo, token)

with st.sidebar.expander("🔧 Streamlit Cloud Secrets"):
    st.markdown("Enter your Streamlit Cloud app ID and token")
    token_input = st.text_input("Streamlit Cloud Token", type="password")
    app_id = st.text_input("Streamlit App ID")
    if st.button("Push Secrets"):
        secrets = {
            "EMAIL_USER": st.text_input("EMAIL_USER"),
            "EMAIL_PASS": st.text_input("EMAIL_PASS"),
            "DATABASE_URL": st.text_input("DATABASE_URL"),
            "SECRET_KEY": st.text_input("SECRET_KEY")
        }
        configure_secrets(token_input, app_id, secrets)


from app.log_viewer import view_logs
st.sidebar.markdown("### 📜 Logs")
view_logs()

# You can add Google/Microsoft OAuth to your Streamlit-authenticator setup
# as an advanced extension or use third-party OIDC integrations


from app.plugin_manager import plugin_ui
from app.realtime_logs import stream_logs

with st.sidebar.expander("🧩 Plugin System"):
    plugin_ui()

with st.sidebar.expander("📡 Live Logs"):
    stream_logs()


from app.multiuser_dashboard import user_dashboard

st.sidebar.subheader("📂 Multi-User Dashboards")
user = st.session_state.get("username", "guest")
user_dashboard(user)
