
import streamlit as st
import subprocess
import os
from pathlib import Path

PLUGIN_DIR = "plugins"

def setup_venv(plugin_path):
    venv_path = plugin_path / ".venv"
    if not venv_path.exists():
        subprocess.run(["python3", "-m", "venv", str(venv_path)])
        subprocess.run([str(venv_path / "bin" / "pip"), "install", "-r", str(plugin_path / "requirements.txt")])
    return venv_path

def launch_plugin(plugin_name):
    plugin_path = Path(PLUGIN_DIR) / plugin_name
    main_path = plugin_path / "main.py"
    if main_path.exists():
        venv_path = setup_venv(plugin_path)
        subprocess.Popen([
            str(venv_path / "bin" / "streamlit"),
            "run",
            str(main_path),
            "--server.port=0"
        ])
        st.success(f"🚀 Launched isolated: {plugin_name}")
    else:
        st.error("main.py not found in plugin directory.")

def plugin_ui():
    st.subheader("🧩 Plugin Manager (Isolated Apps)")
    plugins = [f.name for f in Path(PLUGIN_DIR).iterdir() if f.is_dir()]
    selected = st.selectbox("Select a Plugin", plugins)
    if st.button("Launch Plugin"):
        launch_plugin(selected)
