
import os
from pathlib import Path

PLUGIN_DIR = "plugins"
NGINX_CONFIG_FILE = "nginx.conf"

def generate_nginx_config(base_domain="plugins.gbt-editor.com"):
    ports = range(8502, 8600)
    plugins = [p.name for p in Path(PLUGIN_DIR).iterdir() if p.is_dir()]
    nginx_entries = []

    for idx, plugin in enumerate(plugins):
        port = ports[idx]
        nginx_entries.append(f'''
server {{
    listen 80;
    server_name {plugin}.{base_domain};

    location / {{
        proxy_pass http://localhost:{port};
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
    }}
}}''')

    with open(NGINX_CONFIG_FILE, "w") as f:
        f.write("\n".join(nginx_entries))

    return nginx_entries
