
import streamlit as st
import os

USER_PLUGINS = {
    "admin": ["analytics_dashboard", "ai_trainer"],
    "dev_user": ["dev_toolkit"],
    "guest": []
}

def user_dashboard(username):
    st.subheader(f"🧑‍💻 {username}'s Dashboard")
    plugins = USER_PLUGINS.get(username, [])
    if not plugins:
        st.info("No plugins assigned to your role.")
        return
    for p in plugins:
        st.markdown(f"- {p} — [Launch](/launch?plugin={p})")
