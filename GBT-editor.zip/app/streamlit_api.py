
import streamlit as st
import requests
import os

def configure_secrets(token, app_id, secrets_dict):
    url = f"https://api.streamlit.io/v1/apps/{app_id}/secrets"
    headers = {"Authorization": f"Bearer {token}", "Content-Type": "application/json"}
    response = requests.put(url, headers=headers, json={"secrets": secrets_dict})
    if response.status_code == 200:
        st.success("✅ Secrets configured successfully.")
    else:
        st.error(f"❌ Failed to configure secrets: {response.text}")
