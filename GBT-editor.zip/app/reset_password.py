
import streamlit as st
from app.db import SessionLocal, User
from app.email_utils import send_reset_email
import random
import bcrypt

def reset_password():
    st.title("🔐 Reset Password with Email Confirmation")

    step = st.session_state.get("step", 1)

    if step == 1:
        username = st.text_input("Username")
        email = st.text_input("Registered Email")

        if st.button("Send Code"):
            db = SessionLocal()
            user = db.query(User).filter_by(username=username, email=email).first()
            if user:
                code = str(random.randint(100000, 999999))
                st.session_state.code = code
                st.session_state.username = username
                send_reset_email(email, code)
                st.success("Reset code sent to your email.")
                st.session_state.step = 2
            else:
                st.error("Invalid username or email")
            db.close()

    elif step == 2:
        entered_code = st.text_input("Enter Code from Email")
        if entered_code == st.session_state.get("code"):
            new_password = st.text_input("New Password", type="password")
            if st.button("Update Password"):
                db = SessionLocal()
                user = db.query(User).filter_by(username=st.session_state["username"]).first()
                user.password = bcrypt.hashpw(new_password.encode(), bcrypt.gensalt()).decode()
                db.commit()
                db.close()
                st.success("Password updated!")
                st.session_state.step = 1
        else:
            st.warning("Enter the correct code sent to your email.")
