
import streamlit as st
import os
import subprocess

def deploy_from_app():
    st.title("🚀 Deploy to Streamlit Cloud")

    st.warning("This will attempt to push to GitHub and trigger Streamlit Cloud deployment.")

    github_repo = st.text_input("GitHub Repo URL (must be yours)", "https://github.com/youruser/GBT-editor")
    branch = st.text_input("Branch", "main")

    if st.button("Push and Deploy"):
        try:
            if not os.path.exists(".git"):
                subprocess.run(["git", "init"])
                subprocess.run(["git", "remote", "add", "origin", github_repo])
            subprocess.run(["git", "add", "."])
            subprocess.run(["git", "commit", "-m", "Auto deploy from app"])
            subprocess.run(["git", "branch", "-M", branch])
            subprocess.run(["git", "push", "-u", "origin", branch], check=True)

            st.success("✅ Code pushed to GitHub! Streamlit Cloud will auto-deploy.")
            st.info("You can now go to https://streamlit.io/cloud and select your repo.")

        except subprocess.CalledProcessError as e:
            st.error("Git push failed. Ensure you have GitHub access and a repo initialized.")
