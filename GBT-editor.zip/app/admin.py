
import streamlit as st
from app.db import SessionLocal, User
import pandas as pd
import os

def admin_panel():
    st.subheader("👑 Admin Panel")

    tab1, tab2 = st.tabs(["🔐 Users", "🪵 Logs"])

    with tab1:
        db = SessionLocal()
        users = db.query(User).all()
        data = [{"Username": u.username, "Role": u.role, "Active": u.is_active, "Created": u.created_at} for u in users]
        df = pd.DataFrame(data)
        st.dataframe(df)

        if st.button("Add Admin User"):
            new_user = User(username="admin2", password="admin2pass", role="admin")
            db.add(new_user)
            db.commit()
            st.success("Admin user created.")

        db.close()

    with tab2:
        if os.path.exists("app/gbt_editor.log"):
            with open("app/gbt_editor.log") as f:
                logs = f.read()
            st.text_area("Logs", logs, height=300)
        else:
            st.info("No logs found.")
