
import streamlit as st
import requests
import os

GITHUB_CLIENT_ID = os.getenv("GITHUB_CLIENT_ID")
GITHUB_CLIENT_SECRET = os.getenv("GITHUB_CLIENT_SECRET")
REDIRECT_URI = "http://localhost:8501"  # update if deployed

def get_github_token():
    code = st.experimental_get_query_params().get("code", [None])[0]
    if code:
        token_res = requests.post(
            "https://github.com/login/oauth/access_token",
            headers={"Accept": "application/json"},
            data={
                "client_id": GITHUB_CLIENT_ID,
                "client_secret": GITHUB_CLIENT_SECRET,
                "code": code,
                "redirect_uri": REDIRECT_URI
            }
        )
        token_json = token_res.json()
        return token_json.get("access_token")
    return None

def github_oauth_flow():
    st.write("### GitHub OAuth Login")
    auth_url = (
        f"https://github.com/login/oauth/authorize?client_id={GITHUB_CLIENT_ID}&redirect_uri={REDIRECT_URI}&scope=repo"
    )
    st.markdown(f"[Click here to authorize with GitHub]({auth_url})")

def deploy_status(repo, token):
    headers = {
        "Authorization": f"token {token}",
        "Accept": "application/vnd.github.v3+json"
    }
    res = requests.get(f"https://api.github.com/repos/{repo}/actions/runs", headers=headers)
    if res.status_code == 200:
        runs = res.json().get("workflow_runs", [])
        if runs:
            latest = runs[0]
            status = latest["status"]
            conclusion = latest["conclusion"]
            st.info(f"Latest deploy status: **{status}**, result: **{conclusion}**")
        else:
            st.warning("No deployment runs found.")
    else:
        st.error("Failed to fetch GitHub Actions runs.")
