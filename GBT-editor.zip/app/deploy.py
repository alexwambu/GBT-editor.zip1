
import streamlit as st
import subprocess
import os

def deploy_interface():
    st.subheader("🚀 Deploy GBT-editor to Streamlit Cloud")

    repo = st.text_input("GitHub Repo URL (e.g., https://github.com/yourname/GBT-editor)")
    branch = st.text_input("Branch", "main")
    main_file = st.text_input("Main File Path", "app/main.py")
    deploy_btn = st.button("Push to GitHub and Deploy")

    if deploy_btn and repo:
        st.write("⏳ Preparing deployment...")
        with st.spinner("Pushing code and deploying..."):
            try:
                subprocess.run(["git", "init"])
                subprocess.run(["git", "remote", "add", "origin", repo])
                subprocess.run(["git", "add", "."])
                subprocess.run(["git", "commit", "-m", "Auto deploy from app"])
                subprocess.run(["git", "push", "-u", "origin", branch, "--force"])
                st.success("✅ Pushed to GitHub!")

                # Launch Streamlit deploy URL
                deploy_url = f"https://share.streamlit.io/{repo.replace('https://github.com/', '')}/{branch}/{main_file}"
                st.markdown(f"[🌐 View App on Streamlit Cloud]({deploy_url})")

            except Exception as e:
                st.error(f"❌ Deployment failed: {e}")
