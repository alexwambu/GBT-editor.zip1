
import streamlit as st
import importlib.util
import traceback
from pathlib import Path

def run_plugin_safely(plugin_name):
    plugin_path = Path("plugins") / plugin_name / "main.py"
    try:
        spec = importlib.util.spec_from_file_location(plugin_name, str(plugin_path))
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)
    except Exception as e:
        st.error(f"⚠️ Plugin '{plugin_name}' failed to load.")
        st.text(traceback.format_exc())
