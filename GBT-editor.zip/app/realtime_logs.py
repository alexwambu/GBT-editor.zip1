
import streamlit as st
from streamlit_autorefresh import st_autorefresh

def stream_logs(log_file="app/app.log"):
    st_autorefresh(interval=3000, key="log_refresh")
    st.subheader("📡 Realtime Logs")
    try:
        with open(log_file, "r") as f:
            logs = f.readlines()[-100:]
        st.text("".join(logs))
    except FileNotFoundError:
        st.warning("Log file not found.")
