
from fastapi import FastAPI, Request
import os
import subprocess
import logging

app = FastAPI()

@app.post("/webhook")
async def webhook_handler(request: Request):
    payload = await request.json()
    logging.info(f"Webhook triggered: {payload}")
    subprocess.Popen(["sh", "restart.sh"])  # launch restart
    return {"status": "Restart triggered"}
