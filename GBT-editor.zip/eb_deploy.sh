
#!/bin/bash
APP_NAME="gbteditor-app"
ENV_NAME="gbt-editor-env"
ZIP_FILE="app.zip"

zip -r $ZIP_FILE . -x ".github/*"

eb init $APP_NAME --platform python-3.13 --region us-east-1
eb use $ENV_NAME || eb create $ENV_NAME
eb deploy
