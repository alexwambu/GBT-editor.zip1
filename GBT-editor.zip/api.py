
from fastapi import FastAPI, HTTPException
from app.db import SessionLocal, User
import bcrypt

app = FastAPI()

@app.post("/api/login")
def login(username: str, password: str):
    db = SessionLocal()
    user = db.query(User).filter_by(username=username).first()
    db.close()
    if user and bcrypt.checkpw(password.encode(), user.password.encode()):
        return {"message": "Login successful", "role": user.role}
    raise HTTPException(status_code=401, detail="Invalid credentials")

@app.get("/api/users")
def list_users():
    db = SessionLocal()
    users = db.query(User).all()
    result = [{"username": u.username, "role": u.role, "email": u.email} for u in users]
    db.close()
    return result
