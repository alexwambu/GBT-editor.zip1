
#!/bin/bash
echo "🔁 Restarting Streamlit App..."
pkill -f streamlit
sleep 2
streamlit run app/main.py &
