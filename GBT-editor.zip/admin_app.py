
import streamlit as st
from app.db import SessionLocal, User
from app.admin import admin_panel
import bcrypt

def admin_dashboard():
    st.set_page_config(page_title="GBT-editor Admin", layout="wide")
    st.title("🔐 Admin Dashboard")

    menu = ["Login", "Reset Password"]
    choice = st.sidebar.selectbox("Menu", menu)

    if choice == "Login":
        username = st.text_input("Username")
        password = st.text_input("Password", type="password")
        if st.button("Login"):
            db = SessionLocal()
            user = db.query(User).filter_by(username=username).first()
            if user and bcrypt.checkpw(password.encode(), user.password.encode()):
                st.success(f"Welcome {user.username}")
                admin_panel()
            else:
                st.error("Invalid credentials")
            db.close()

    elif choice == "Reset Password":
        from app.reset_password import reset_password
        reset_password()
