
# GBT‑Editor

## Deployment on Streamlit Cloud
1. Push this repo to GitHub (e.g., `GBT-editor`)
2. Go to https://streamlit.io/cloud and click "New App"
3. Select this repo and set the main file path as:
```
app/main.py
```
4. Click Deploy.

## Deployment on AWS (Elastic Beanstalk)
- Make sure to set GitHub secrets:
  - AWS_ACCESS_KEY_ID
  - AWS_SECRET_ACCESS_KEY

- AWS EB app name: gbteditor-app
- AWS EB env name: gbt-editor-env

- Push to `main` branch and GitHub Actions will auto-deploy.


---

### 🔑 Admin Dashboard

To run the separate admin dashboard:
```bash
streamlit run admin_app.py
```

Login:
- **Username**: `admin`
- **Password**: `adminpass`


---

### 🛠 First Time Setup

To create the users table in the database:
```bash
python -c "from app.db import Base, engine; Base.metadata.create_all(bind=engine)"
```

---

### 🔐 Reset Password (Admin Dashboard)

Click **Reset Password** in the sidebar of `admin_app.py` route.


---

### 📧 Password Reset Email

Set these in your `.env`:
```
EMAIL_USER=your_email@gmail.com
EMAIL_PASS=your_password
```

---

### 🔌 FastAPI Endpoints

Run the API:
```bash
uvicorn api:app --reload
```

Endpoints:
- `POST /api/login`
- `GET /api/users`

---

### 🛠 CLI Admin User Creation
```bash
python create_admin.py
```


---

### ☁️ Streamlit Cloud Auto Deployment (From UI)
- Go to the sidebar → Mode → `Deploy`
- Paste your GitHub repo URL
- Click `Push to GitHub and Deploy`

---

### 🔐 Secrets
Add this to `.streamlit/secrets.toml`:
```toml
[general]
email = "your_email@gmail.com"

[credentials]
EMAIL_USER = "your_email@gmail.com"
EMAIL_PASS = "your_email_password"
DATABASE_URL = "postgresql://your_user:your_password@your_host:5432/your_db"
SECRET_KEY = "your_streamlit_secret_key"
```


---

### 🚀 Streamlit Cloud Deployment From Interface

- In your deployed app sidebar, click `🚀 Deploy GBT-editor`
- The app will push to your GitHub repo and notify Streamlit Cloud to deploy
- Make sure `.streamlit/secrets.toml` is configured locally or Streamlit Cloud Secrets are set



---

### 🧪 GitHub OAuth + Deploy Tracker

To use GitHub OAuth and auto track deployment:
1. Register an OAuth App in GitHub → https://github.com/settings/developers
2. Set `GITHUB_CLIENT_ID` and `GITHUB_CLIENT_SECRET` in `.env`
3. Start the app and click "Authorize GitHub"
4. View deploy status using GitHub Actions API

---

### 🔐 Streamlit Cloud Secrets via API

You can now push secrets to your deployed Streamlit app from within the app itself.

Steps:
1. Get your **Streamlit Cloud personal token** from [cloud.streamlit.io](https://share.streamlit.io)
2. Locate your app ID (usually in URL)
3. Enter and push secrets via the sidebar in the deployed app



---

### 🔁 CI/CD Webhook Endpoint

To trigger backend redeploys, call:
```http
POST /webhook
```

Used for GitHub/GitLab/Cloudflare Pages integration.

---

### 📜 Live Log Viewer

- Shows last 100 lines from `app/app.log`
- Refreshable from within the app

---

### 🔐 Google/Microsoft OAuth Support

To add OAuth with Google or Microsoft:
1. Register on:
   - [Google Cloud Console](https://console.cloud.google.com/)
   - [Microsoft Azure Portal](https://portal.azure.com/)
2. Add client IDs/secrets to `.env`
3. Integrate with OIDC or use `streamlit-authenticator` extensions


---

### 🌐 Subdomain Routing for Hosted Apps (Blueprint)

1. **Structure**: Each plugin runs as an isolated Streamlit app (via venv)
2. **Deploy** with reverse proxy (e.g., NGINX):

```nginx
server {
    listen 80;
    server_name plugin1.gbt-editor.com;

    location / {
        proxy_pass http://localhost:8502;
        proxy_set_header Host $host;
    }
}
```

3. **DNS**: Map `plugin1.gbt-editor.com` to your server IP

4. **Launch apps** on different ports, then route via subdomain

You can automate this using Docker+NGINX or Traefik reverse proxy

